-- ================================================================
-- 1. DROP EXISTING OBJECTS (CLEAN SLATE TO PREVENT DUPLICATES)
-- ================================================================
DROP FUNCTION IF EXISTS get_nearby_hospitals(DOUBLE PRECISION, DOUBLE PRECISION, INT);
DROP TABLE IF EXISTS emergency_logs;
DROP TABLE IF EXISTS medical_protocols;
DROP TABLE IF EXISTS hospitals;

-- ================================================================
-- 2. CREATE HOSPITALS TABLE
-- ================================================================
CREATE TABLE hospitals (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    city TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    contact_number TEXT NOT NULL,
    emergency_services BOOLEAN DEFAULT TRUE,
    specialty_tags TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================================
-- 3. CREATE MEDICAL PROTOCOLS TABLE
-- ================================================================
CREATE TABLE medical_protocols (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    incident_name TEXT UNIQUE NOT NULL,
    symptoms_keywords TEXT[] NOT NULL,
    steps_to_take TEXT NOT NULL,
    warning_notes TEXT,
    image_url TEXT,
    video_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================================
-- 4. CREATE EMERGENCY LOGS TABLE
-- ================================================================
CREATE TABLE emergency_logs (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    incident_searched TEXT,
    user_latitude DOUBLE PRECISION,
    user_longitude DOUBLE PRECISION,
    matched_hospital_id BIGINT REFERENCES hospitals(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================================
-- 5. INSERT 52 HOSPITALS ACROSS MAHARASHTRA
-- ================================================================
INSERT INTO hospitals (name, address, city, latitude, longitude, contact_number, specialty_tags) VALUES
-- THANE & MUMBAI SUBURBS
('Jupiter Hospital', 'Eastern Express Highway, Near Viviana Mall, Thane West', 'Thane', 19.2081, 72.9712, '+91-22-21725555', ARRAY['24/7 ER', 'Trauma Care', 'Cardiology', 'ICU']),
('Bethany Hospital', 'Pokhran Road No. 2, Near Unnathi Gardens, Thane West', 'Thane', 19.2215, 72.9698, '+91-22-21725100', ARRAY['24/7 ER', 'Critical Care', 'General Surgery']),
('Currae Specialty Hospital', 'High Street Shopping Mall, Kapurbawdi Circle, Thane West', 'Thane', 19.2198, 72.9785, '+91-22-25862000', ARRAY['24/7 ER', 'Ortho', 'Surgery']),
('Horizon Prime Hospital', 'Ghodbunder Road, Patlipada, Thane West', 'Thane', 19.2523, 72.9691, '+91-22-25845000', ARRAY['24/7 ER', 'Critical Care', 'Cardiology']),
('Titan Hospital', 'Manpada, Ghodbunder Rd, Thane West', 'Thane', 19.2331, 72.9734, '+91-22-25890000', ARRAY['24/7 ER', 'Trauma Center', 'ICU']),
('Dr. Bhanushali Hospital', 'Station Road, Near Railway Station, Thane West', 'Thane', 19.1862, 72.9754, '+91-22-25343456', ARRAY['24/7 ER', 'General Medicine']),
('Kaushalya Medical Foundation Trust Hospital', 'Ganeshwadi, Panchpakhadi, Thane West', 'Thane', 19.1988, 72.9688, '+91-22-25454000', ARRAY['24/7 ER', 'Oncology', 'Cardiology']),
('Hiranandani Hospital Thane', 'Ghodbunder Rd, Hiranandani Estate, Thane West', 'Thane', 19.2612, 72.9810, '+91-22-25866000', ARRAY['24/7 ER', 'Multispecialty', 'Trauma']),

-- MUMBAI CITY & SUBURBS
('KEM Hospital', 'Acharya Donde Marg, Parel', 'Mumbai', 19.0014, 72.8412, '+91-22-24107000', ARRAY['24/7 Public ER', 'Level 1 Trauma Center', 'Pediatrics']),
('Sion Hospital (LTMGH)', 'Sion West', 'Mumbai', 19.0361, 72.8593, '+91-22-24076381', ARRAY['24/7 Public ER', 'Burns Unit', 'Trauma Care']),
('Lilavati Hospital', 'A-791, Bandra Reclamation, Bandra West', 'Mumbai', 19.0512, 72.8289, '+91-22-26751000', ARRAY['24/7 ER', 'Level 1 Trauma', 'Neurosurgery']),
('Nanavati Max Super Speciality Hospital', 'SV Rd, Vile Parle West', 'Mumbai', 19.0968, 72.8385, '+91-22-68360000', ARRAY['24/7 ER', 'Organ Transplant', 'Oncology']),
('Sir H. N. Reliance Foundation Hospital', 'Raja Rammohan Roy Rd, Girgaon', 'Mumbai', 18.9567, 72.8189, '+91-22-61305000', ARRAY['24/7 ER', 'Stroke Center', 'Cardiology']),
('Kokilaben Dhirubhai Ambani Hospital', 'Four Bungalows, Andheri West', 'Mumbai', 19.1311, 72.8253, '+91-22-30696969', ARRAY['24/7 ER', 'Level 1 Trauma', 'Pediatric ICU']),
('Fortis Hospital Mulund', 'Mulund - Goregaon Link Rd, Bhandup West', 'Mumbai', 19.1622, 72.9431, '+91-22-67994185', ARRAY['24/7 ER', 'Cardiac Care', 'Organ Transplant']),
('Bombay Hospital & Medical Research Centre', 'Marine Lines, Cibo Market', 'Mumbai', 18.9438, 72.8281, '+91-22-22067676', ARRAY['24/7 ER', 'Neuroscience', 'Cardiology']),
('Breach Candy Hospital', 'Bhulabhai Desai Marg', 'Mumbai', 18.9718, 72.8051, '+91-22-23667788', ARRAY['24/7 ER', 'ICU', 'General Surgery']),
('Dr L H Hiranandani Hospital Powai', 'Hillside Rd, Powai', 'Mumbai', 19.1197, 72.9113, '+91-22-25763300', ARRAY['24/7 ER', 'Multispecialty', 'Critical Care']),
('S.L. Raheja Hospital (Fortis Associate)', 'Mahim West', 'Mumbai', 19.0433, 72.8427, '+91-22-66529999', ARRAY['24/7 ER', 'Diabetic Care', 'Oncology']),
('Hinduja Hospital', 'Veer Savarkar Marg, Mahim', 'Mumbai', 19.0333, 72.8383, '+91-22-24451515', ARRAY['24/7 ER', 'Multispecialty', 'Trauma']),

-- NAVI MUMBAI & PANVEL
('Apollo Hospitals Belapur', 'Plot No. 13, Off Thane-Belapur Rd, Belapur', 'Navi Mumbai', 19.0222, 73.0388, '+91-22-33503350', ARRAY['24/7 ER', 'Stroke Unit', 'Organ Transplant']),
('MGM Hospital Vashi', 'Sector 3, Vashi', 'Navi Mumbai', 19.0768, 72.9989, '+91-22-27822203', ARRAY['24/7 ER', 'Trauma Care', 'General Medicine']),
('Reliance Hospital Koparkhairane', 'Thane Belapur Road, Kopar Khairane', 'Navi Mumbai', 19.1068, 73.0118, '+91-22-39199999', ARRAY['24/7 ER', 'Cardiac Sciences', 'Neuro Care']),
('MGM Hospital Kamothe', 'Sector 1, Kamothe, Panvel', 'Navi Mumbai', 19.0210, 73.0932, '+91-22-27437900', ARRAY['24/7 Public ER', 'Trauma Center', 'ICU']),

-- PUNE REGION
('Ruby Hall Clinic', '40 Sassoon Road', 'Pune', 18.5323, 73.8732, '+91-20-66455100', ARRAY['24/7 ER', 'Level 1 Trauma', 'Cardiac Care']),
('Sassoon General Hospital', 'Near Pune Railway Station', 'Pune', 18.5262, 73.8711, '+91-20-26128000', ARRAY['24/7 Public ER', 'Trauma Center', 'Burns Unit']),
('Deenanath Mangeshkar Hospital', 'Erandwane', 'Pune', 18.5028, 73.8315, '+91-20-40151000', ARRAY['24/7 ER', 'Multispecialty', 'Pediatric ICU']),
('Jehangir Hospital', '32 Sassoon Road', 'Pune', 18.5309, 73.8738, '+91-20-66859999', ARRAY['24/7 ER', 'Critical Care', 'Ortho']),
('Sahyadri Super Speciality Hospital', 'Deccan Gymkhana', 'Pune', 18.5146, 73.8422, '+91-20-67213000', ARRAY['24/7 ER', 'Neurosurgery', 'Hematology']),
('Jupiter Hospital Pune', 'Baner - Balewadi Rd, Baner', 'Pune', 18.5639, 73.7781, '+91-20-27992799', ARRAY['24/7 ER', 'Trauma Center', 'Transplant']),
('Manipal Hospital Kharadi', 'Kharadi', 'Pune', 18.5524, 73.9351, '+91-20-61656666', ARRAY['24/7 ER', 'Cardiology', 'ICU']),
('Aditya Birla Memorial Hospital', 'Chinchwad', 'Pune', 18.6341, 73.7845, '+91-20-30717500', ARRAY['24/7 ER', 'Multispecialty', 'Trauma Care']),

-- NAGPUR REGION
('Kingsway Hospitals', 'Near Kasturchand Park', 'Nagpur', 21.1539, 79.0831, '+91-712-6789100', ARRAY['24/7 ER', 'Trauma Center', 'Cardiology']),
('AIIMS Nagpur', 'MIHAN', 'Nagpur', 21.0503, 79.0270, '+91-712-2801000', ARRAY['24/7 Public ER', 'Apex Trauma Center']),
('Alexis Multispecialty Hospital', 'Mankapur', 'Nagpur', 21.1892, 79.0718, '+91-712-7120000', ARRAY['24/7 ER', 'Neurosciences', 'Orthopedics']),
('Government Medical College & Hospital (GMC)', 'Hanuman Nagar', 'Nagpur', 21.1278, 79.0988, '+91-712-2743588', ARRAY['24/7 Public ER', 'Burns Unit', 'Trauma']),

-- NASHIK REGION
('Sahyadri Super Speciality Hospital', 'Mumbai Naka', 'Nashik', 19.9882, 73.7801, '+91-253-6608888', ARRAY['24/7 ER', 'Cardiology', 'Neurosurgery']),
('Wockhardt Hospitals', 'Wani House, Near Mumbai Naka', 'Nashik', 19.9856, 73.7825, '+91-253-6624444', ARRAY['24/7 ER', 'Critical Care', 'Trauma']),
('Apollo Hospitals Nashik', 'Swaminarayan Nagar, Panchavati', 'Nashik', 20.0210, 73.8055, '+91-253-2303000', ARRAY['24/7 ER', 'Oncology', 'Emergency Medicine']),

-- CHHATRAPATI SAMBHAJINAGAR (AURANGABAD)
('MGM Medical College & Hospital', 'N-6, CIDCO', 'Chhatrapati Sambhajinagar', 19.8821, 75.3582, '+91-240-6601100', ARRAY['24/7 ER', 'Trauma Care', 'Pediatric ICU']),
('Medicover Hospitals', 'Near API Corner, Chikalthana', 'Chhatrapati Sambhajinagar', 19.8732, 75.3789, '+91-240-6650000', ARRAY['24/7 ER', 'Cardiac Care', 'Neuro Surgery']),
('Government Medical College (Ghati)', 'Panchakki Road', 'Chhatrapati Sambhajinagar', 19.8923, 75.3189, '+91-240-2403331', ARRAY['24/7 Public ER', 'Trauma Center']),

-- KOLHAPUR REGION
('Apple Saraswati Multispecialty Hospital', 'Kadamwadi', 'Kolhapur', 16.7112, 74.2489, '+91-231-2689000', ARRAY['24/7 ER', 'Critical Care', 'Trauma']),
('Aster Aadhar Hospital', 'Near Shastri Nagar', 'Kolhapur', 16.6854, 74.2281, '+91-231-6622555', ARRAY['24/7 ER', 'Cardiology', 'Emergency']),
('CPR General Hospital', 'Near Dasara Chowk', 'Kolhapur', 16.6991, 74.2230, '+91-231-2654321', ARRAY['24/7 Public ER', 'Trauma Center']),

-- SOLAPUR REGION
('Ashwini Sahakari Rupralayam Hospital', 'North Sadar Bazar', 'Solapur', 17.6698, 75.9082, '+91-217-2319900', ARRAY['24/7 ER', 'Cardiology', 'ICU']),
('Yashodhara Super Speciality Hospital', 'Siddheshwar Peth', 'Solapur', 17.6588, 75.9011, '+91-217-2729900', ARRAY['24/7 ER', 'Trauma Center', 'Surgery']),
('V M Government Medical College Hospital', 'Civil Lines', 'Solapur', 17.6712, 75.9123, '+91-217-2310499', ARRAY['24/7 Public ER', 'Emergency Unit']),

-- NANDED REGION
('Dr. Shankarrao Chavan Government Medical College', 'Vishnupuri', 'Nanded', 19.1123, 77.2911, '+91-2462-229270', ARRAY['24/7 Public ER', 'Trauma Center', 'ICU']),
('Lotus Hospital', 'Vazirabad', 'Nanded', 19.1589, 77.3156, '+91-2462-248888', ARRAY['24/7 ER', 'Pediatrics', 'Critical Care']),
('Sanjeevani Hospital', 'Doctor Lane', 'Nanded', 19.1534, 77.3189, '+91-2462-234567', ARRAY['24/7 ER', 'Emergency Medicine']);

-- ================================================================
-- 6. INSERT 36 MEDICAL PROTOCOLS (DAY-TO-DAY & SEVERE ACCIDENTS)
-- ================================================================
INSERT INTO medical_protocols (incident_name, symptoms_keywords, steps_to_take, warning_notes, image_url, video_url) VALUES
(
    'Fainting / Unconsciousness', 
    ARRAY['fainted', 'unconscious', 'passed out', 'dizzy', 'blackout', 'collapsed'],
    '1. Check for breathing and responsiveness.
2. Position the person flat on their back.
3. Elevate legs 12 inches (30 cm) to restore blood flow to the brain.
4. Loosen tight clothing around neck and waist.
5. If unconscious over 1 minute, call 108 emergency immediately.',
    'Do NOT give food or water while unconscious. Do NOT splash cold water on face.',
    'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Cardiac Arrest / CPR Needed', 
    ARRAY['heart attack', 'cardiac arrest', 'chest pain', 'not breathing', 'no pulse'],
    '1. Call 108 emergency immediately.
2. Place hands in the center of the chest.
3. Push hard and fast (100–120 compressions/min) to the beat of "Stayin Alive".
4. Continue CPR until help arrives or AED is attached.',
    'If an AED is available, switch it on and follow voice instructions immediately.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/cosVBV96E22'
),
(
    'Severe Choking', 
    ARRAY['choking', 'cannot breathe', 'gasping', 'throat blocked', 'blue lips'],
    '1. Stand behind the person and wrap arms around waist.
2. Make a fist above the navel and grasp with other hand.
3. Perform quick, upward abdominal thrusts until object is dislodged.',
    'If person loses consciousness, lower them gently to the floor and start CPR compressions.',
    'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/3m3_oZ4kC58'
),
(
    'Chemical Eye Splash', 
    ARRAY['acid', 'chemical', 'eye burn', 'splash', 'chemical burn', 'lab accident'],
    '1. Flush affected eye with clean running tap water continuously for 15-20 minutes.
2. Hold eyelids open wide during flushing.
3. Remove contact lenses if present while flushing.
4. Transport immediately to an eye hospital or ER.',
    'Do NOT rub the eye. Do NOT use neutralizing liquids, eye drops, or creams.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/kR5A1V_cI_Q'
),
(
    'Thermal & Fire Burns',
    ARRAY['burn', 'fire', 'scald', 'hot water', 'blister', 'skin burn', 'steam burn'],
    '1. Cool burn immediately under cool running tap water for 10-20 minutes.
2. Remove tight items like rings before swelling starts.
3. Cover loosely with clean, non-stick sterile bandage or plastic cling film.
4. Seek ER care if burn is larger than 3 inches or on face, hands, or joints.',
    'Do NOT apply ice, butter, toothpaste, or oil. Do NOT pop blisters.',
    'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Snake Bite',
    ARRAY['snake', 'snake bite', 'venom', 'fang marks', 'viper', 'cobra', 'krait'],
    '1. Keep victim strictly calm and still to slow venom spread.
2. Position bitten limb below or at heart level.
3. Remove rings/watch near bite before swelling occurs.
4. Transport immediately to a hospital with anti-snake venom (ASV).',
    'Do NOT cut wound, suck venom out, apply tourniquet, or apply ice.',
    'https://images.unsplash.com/photo-1531386151447-fd76ad50012f?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Animal / Rabid Dog Bite',
    ARRAY['dog bite', 'animal bite', 'rabies', 'monkey bite', 'cat scratch', 'stray bite'],
    '1. Wash bite immediately with soap and warm running water for 15 minutes.
2. Apply antiseptic (Betadine or alcohol) if available.
3. Cover loosely with clean bandage.
4. Visit hospital within 24 hours for Anti-Rabies Vaccine (ARV) and Tetanus dose.',
    'Do NOT cover tightly without thorough soap washing. Rabies is 100% fatal once symptoms start.',
    'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Electrical Shock',
    ARRAY['electric shock', 'electrocution', 'current', 'live wire', 'outlet shock', 'high voltage'],
    '1. Do NOT touch person if still in contact with power source.
2. Switch off main power circuit breaker immediately.
3. If impossible to turn off, push person away using dry wooden stick or plastic broom handle.
4. Check breathing once safe; perform CPR if unresponsive.',
    'Never use metal objects or touch water near live electrical wires.',
    'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Heat Stroke & Severe Exhaustion',
    ARRAY['heat stroke', 'sun stroke', 'dehydration', 'high fever', 'dizziness', 'hot skin', 'summer collapse'],
    '1. Move person to cool shaded or air-conditioned room.
2. Cool body fast with cold wet cloths, ice packs on neck, armpits, and groin.
3. Fan vigorously while misting skin with water.
4. Offer sips of ORS or cold water if conscious.',
    'Heat stroke is a medical emergency. Do NOT give sugary drinks or alcohol.',
    'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Severe Bleeding & Deep Cut Wounds',
    ARRAY['bleeding', 'cut', 'blood', 'hemorrhage', 'wound', 'deep cut', 'gash', 'arterial bleeding'],
    '1. Apply direct firm pressure on wound with sterile pad or clean cloth.
2. Maintain pressure continuously for 10-15 minutes without lifting cloth.
3. Elevate injured area above heart level if possible.
4. Seek emergency care if bleeding continues.',
    'Do NOT remove embedded objects from wound; apply pressure around object instead.',
    'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Bone Fracture & Dislocations',
    ARRAY['fracture', 'broken bone', 'dislocation', 'swelling', 'limb injury', 'broken leg', 'arm fracture'],
    '1. Keep injured area completely still. Do NOT attempt to straighten bones.
2. Immobilize limb using splint (rolled cardboard/wood) padded with cloth.
3. Apply ice pack wrapped in towel for 15 mins to ease swelling.
4. Seek immediate orthopedic emergency care.',
    'Do NOT move victim if spinal or neck fracture is suspected.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Asthma Attack & Severe Wheezing',
    ARRAY['asthma', 'breathing problem', 'wheezing', 'shortness of breath', 'inhaler', 'gasping'],
    '1. Sit person upright comfortably. Do NOT lie them down.
2. Assist them in taking emergency inhaler (Salbutamol/Ventolin).
3. Give 1 puff every 30-60 seconds up to 10 puffs.
4. Call ambulance if no relief after 10 minutes.',
    'Ensure room has fresh air. Keep person calm to avoid tightening airway.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Severe Allergic Reaction (Anaphylaxis)',
    ARRAY['allergy', 'anaphylaxis', 'epipen', 'swollen face', 'hives', 'peanut allergy', 'bee sting allergy'],
    '1. Call 108 emergency immediately.
2. Administer EpiPen into outer thigh muscle and hold 3 seconds.
3. Lay person flat; if struggling to breathe, sit them up gently.
4. Administer second EpiPen in 5-15 mins if symptoms persist.',
    'Anaphylaxis can close airways in minutes. Treat as absolute life threat.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Brain Stroke Emergency (FAST)',
    ARRAY['stroke', 'paralysis', 'slurred speech', 'face drooping', 'arm weakness', 'brain stroke', 'paralytic attack'],
    '1. Check FAST: Face droop, Arm weakness, Speech slurred, Time to call 108.
2. Lay person on their side with head elevated slightly.
3. Note exact time symptoms began.',
    'Do NOT give food, water, or aspirin. Medical intervention within 3 hours is crucial.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Poisoning & Chemical Ingestion',
    ARRAY['poison', 'ingested poison', 'chemical intake', 'swallowed cleaner', 'toxic', 'pesticide', 'rat poison'],
    '1. Identify chemical swallowed, quantity, and time.
2. Call national poison emergency line or 108 immediately.
3. Rinse mouth with clean water if conscious.',
    'Do NOT induce vomiting unless instructed by medical specialists. Acids burn throat twice.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Seizures & Epilepsy Fits',
    ARRAY['seizure', 'fit', 'epilepsy', 'shaking', 'convulsions', 'foaming mouth', 'epileptic attack'],
    '1. Ease person safely to floor away from sharp objects.
2. Cushion head with folded jacket or towel.
3. Turn gently on side (recovery position) to keep airway open.
4. Time seizure duration.',
    'Do NOT force objects into mouth. Do NOT hold or restrain struggling limbs.',
    'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Nosebleed (Epistaxis)',
    ARRAY['nosebleed', 'bleeding nose', 'blood from nose', 'epistaxis', 'nasal bleeding'],
    '1. Sit upright and lean slightly FORWARD.
2. Pinch soft lower nose bridge firmly for 10-15 mins continuously.
3. Breathe through mouth.
4. Apply cold ice pack on nose bridge.',
    'Do NOT lean head backward — blood flows down throat causing choking or vomiting.',
    'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Drowning & Submersion',
    ARRAY['drowning', 'water in lungs', 'swimming accident', 'submersion', 'river drowning', 'pool emergency'],
    '1. Safely retrieve person from water.
2. Place flat on firm ground and check breathing.
3. If not breathing, give 5 rescue breaths then perform 30 chest compressions.
4. Continue 2 rescue breaths to 30 compressions ratio until help arrives.',
    'All near-drowning victims must undergo hospital evaluation even if conscious.',
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Diabetic Low Blood Sugar (Hypoglycemia)',
    ARRAY['low blood sugar', 'diabetes', 'hypoglycemia', 'diabetic shock', 'shaking', 'sweating sugar drop'],
    '1. If conscious, give 15-20g fast-acting sugar: 3-4 glucose tablets, half glass fruit juice, or 1 tbsp sugar.
2. Wait 15 minutes and reassess.
3. Provide meal or snack once recovered.',
    'If unconscious, do NOT pour liquids into mouth. Seek immediate emergency room care.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Head Injury & Concussion',
    ARRAY['head injury', 'concussion', 'head trauma', 'bump on head', 'dizziness head', 'vomiting head', 'skull blow'],
    '1. Lay person down and keep head elevated slightly.
2. Apply cold compress wrapped in cloth to reduce swelling.
3. Watch for severe signs: repeated vomiting, unequal pupils, confusion, memory loss.',
    'Keep victim monitored for 24 hours. Seek immediate ER care if confusion occurs.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Panic Attack & Hyperventilation',
    ARRAY['panic attack', 'hyperventilation', 'rapid breathing', 'anxiety attack', 'chest tightness anxiety'],
    '1. Reassure person calmly that they are safe.
2. Lead box breathing: Inhale 4s, hold 2s, exhale slowly 6s.
3. Move to quiet area and use 5-4-3-2-1 sensory grounding technique.',
    'Do NOT use paper bag breathing without physician approval.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Bee, Wasp & Hornet Stings',
    ARRAY['bee sting', 'wasp sting', 'stinger', 'insect sting', 'swelling sting', 'hornet'],
    '1. Scrape stinger off skin using credit card or fingernail.
2. Wash area with soap and water.
3. Apply ice pack wrapped in cloth for 10 minutes.',
    'Do NOT use tweezers on bee stinger; it squeezes remaining venom into tissue.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Dehydration & Severe Muscle Cramps',
    ARRAY['dehydration', 'heat cramps', 'dry mouth', 'thirst', 'muscle cramps', 'stomach cramps heat'],
    '1. Move to shaded cool area.
2. Sip ORS, electrolyte drinks, or coconut water slowly.
3. Gently stretch and massage cramped muscles.',
    'Avoid caffeinated or alcoholic drinks which aggravate fluid loss.',
    'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'High Fever & Febrile Fits in Children',
    ARRAY['fever', 'high fever', 'febrile fit', 'temperature', 'shivering', 'child fever', 'high temp'],
    '1. Check body temperature with thermometer.
2. Dress child in light clothing and keep room cool.
3. Apply lukewarm damp cloth to forehead, wrists, and neck.
4. Give Paracetamol dosage appropriate for age/weight.',
    'Do NOT use cold ice water baths or alcohol wipes; causes shivering and spikes core temp.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'LPG Gas Leak & Smoke Inhalation',
    ARRAY['gas leak', 'smoke inhalation', 'carbon monoxide', 'choking gas', 'LPG leak', 'cylinder leak', 'fire smoke'],
    '1. Evacuate everyone into fresh open air immediately.
2. Open windows and doors if safe to ventilate.
3. Call fire station / emergency service.
4. Start CPR if victim is unresponsive in fresh air.',
    'Do NOT flip electrical switches, light matches, or create sparks near gas leaks.',
    'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Foreign Object in Ear or Nose',
    ARRAY['object in ear', 'object in nose', 'stuck bead', 'insect in ear', 'ear emergency', 'seed in nose'],
    '1. For insects in ear: tilt head and pour lukewarm mineral oil to float insect out.
2. For nose: blow gently through nose while closing opposite nostril.
3. Seek ENT specialist if object remains stuck.',
    'Do NOT insert tweezers, cotton swabs, or pins into ear or nose; pushes object deeper.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Severe Food Poisoning & Gastroenteritis',
    ARRAY['food poisoning', 'vomiting', 'diarrhea', 'stomach infection', 'stomach cramps', 'nausea', 'loose motions'],
    '1. Rehydrate with small, frequent sips of ORS fluid.
2. Rest stomach for a few hours post-vomiting, then introduce BRAT diet (Banana, Rice, Applesauce, Toast).
3. Monitor for warning signs like blood in stool or high fever.',
    'Seek immediate medical care if severe vomiting persists over 24 hours.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Knocked-Out Permanent Tooth',
    ARRAY['knocked out tooth', 'broken tooth', 'dental emergency', 'tooth loss', 'dental injury', 'sports hit tooth'],
    '1. Pick up tooth strictly by crown (top), NEVER by root.
2. Rinse gently in milk or saline for 2 seconds. Do NOT scrub.
3. Reinsert into socket if possible or store cup in fresh milk.
4. Reach dentist within 30-60 minutes for reimplantation.',
    'Do NOT let tooth dry out. Do NOT clean or store in plain tap water.',
    'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Spinal Injury & Severe Neck Trauma',
    ARRAY['spine injury', 'neck pain', 'fall from height', 'back injury', 'paralysis fall', 'accident spine', 'paralyzed'],
    '1. Call 108 emergency immediately.
2. Keep victim completely still; place heavy rolled towels on both sides of head.
3. Do NOT move victim unless immediate life hazard (fire) exists.',
    'Improper movement of spinal injury victim causes permanent paralysis.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Road Traffic Accident & Heavy Abrasion',
    ARRAY['accident', 'bike crash', 'road rash', 'skid wound', 'abrasion', 'traffic injury', 'car crash'],
    '1. Secure traffic scene to prevent further collisions.
2. Apply direct pressure to heavy bleeding wounds.
3. Wash minor skin road rash with clean water and gentle soap.
4. Cover with sterile gauze and transport to ER.',
    'Do NOT scrub deep gravel embedded in wounds yourself; leave removal to ER surgeons.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Carbon Monoxide Poisoning',
    ARRAY['carbon monoxide', 'generator gas', 'exhaust fumes', 'dizzy home gas', 'silent gas', 'heater gas'],
    '1. Move victim to fresh outdoor air immediately.
2. Call 108 emergency services.
3. Administer oxygen if trained medical assistance is available.',
    'Carbon monoxide is invisible and odorless. Unexplained headache/dizziness in enclosed space is key warning.',
    'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Severe Sunburn & UV Blisters',
    ARRAY['sunburn', 'sun blister', 'uv burn', 'skin red sun', 'beach burn'],
    '1. Take cool shower or apply cold damp compresses.
2. Apply pure aloe vera gel liberally.
3. Drink extra fluids to counter skin dehydration.',
    'Do NOT pop blisters. Avoid further sun exposure until completely healed.',
    'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Electrolyte Imbalance & Heat Collapse',
    ARRAY['heat collapse', 'fainting heat', 'low salt', 'sweating loss', 'cramping heat'],
    '1. Move person to air-conditioned or shaded room.
2. Sip ORS electrolyte solution slowly.
3. Loosen tight clothing and elevate legs slightly.',
    'Do NOT gulp large quantities of plain water at once; sip electrolyte balanced fluids.',
    'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Acid Attack & Corrosive Chemical Burns',
    ARRAY['acid attack', 'acid splash', 'corrosive burn', 'chemical splash skin', 'vitriol'],
    '1. Flush affected body area with huge quantities of clean running water for 30–45 minutes.
2. Gently remove contaminated clothing while flushing.
3. Call 108 emergency immediately.',
    'Do NOT apply ointment, butter, or neutralizing chemicals; chemical reaction generates intense heat.',
    'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/kR5A1V_cI_Q'
),
(
    'Scorpion Sting',
    ARRAY['scorpion', 'scorpion sting', 'red scorpion', 'bite sting', 'stinger pain'],
    '1. Keep victim calm and immobilize stung limb.
2. Wash sting site with soap and clean water.
3. Apply cold compress to control local severe pain.
4. Transport immediately to hospital for Prazosin / Anti-scorpion venom therapy.',
    'Red scorpion stings in India can cause severe heart complications. Urgent medical monitoring is mandatory.',
    'https://images.unsplash.com/photo-1531386151447-fd76ad50012f?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
),
(
    'Crush Injury & Traumatic Entrapment',
    ARRAY['crush injury', 'building collapse', 'trapped limb', 'heavy object fall', 'crush syndrome'],
    '1. Call emergency services and specialized rescue teams immediately.
2. If safe, remove crushing object as quickly as possible.
3. Keep victim calm and warm while monitoring breathing.',
    'Prolonged crushing (>1 hour) releases toxins upon release. Medical teams must manage crush syndrome.',
    'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?auto=format&fit=crop&w=800&q=80',
    'https://www.youtube.com/embed/EaJmzB8YgS0'
);

-- ================================================================
-- 7. DISTANCE & GOOGLE MAPS NAVIGATION FUNCTION
-- ================================================================
CREATE OR REPLACE FUNCTION get_nearby_hospitals(
    user_lat DOUBLE PRECISION,
    user_lng DOUBLE PRECISION,
    limit_count INT DEFAULT 5
)
RETURNS TABLE (
    id BIGINT,
    name TEXT,
    address TEXT,
    city TEXT,
    contact_number TEXT,
    specialty_tags TEXT[],
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    distance_km NUMERIC,
    google_maps_directions_url TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        h.id,
        h.name,
        h.address,
        h.city,
        h.contact_number,
        h.specialty_tags,
        h.latitude,
        h.longitude,
        ROUND(
            (6371 * acos(
                LEAST(1.0, GREATEST(-1.0, 
                    cos(radians(user_lat)) * cos(radians(h.latitude)) * 
                    cos(radians(h.longitude) - radians(user_lng)) + 
                    sin(radians(user_lat)) * sin(radians(h.latitude))
                ))
            ))::numeric, 2
        ) AS distance_km,
        CONCAT(
            'https://www.google.com/maps/dir/?api=1&origin=', 
            user_lat, ',', user_lng, 
            '&destination=', 
            h.latitude, ',', h.longitude, 
            '&travelmode=driving'
        ) AS google_maps_directions_url
    FROM hospitals h
    ORDER BY distance_km ASC
    LIMIT limit_count;
END;
$$;