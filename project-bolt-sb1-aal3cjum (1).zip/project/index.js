import express from 'express';
import cors from 'cors';
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Global validation layout for integration credentials
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY;
const openAIKey = process.env.OPENAI_API_KEY;
const tavilyApiKey = process.env.TAVILY_API_KEY; 

if (!supabaseUrl || !supabaseAnonKey || !openAIKey) {
  console.error("❌ Critical configuration variables are missing from your variables!");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);
const openai = new OpenAI({ apiKey: openAIKey });

// Helper function to search the entire live internet for videos and images dynamically
async function searchLiveInternetMedia(medicalIssue) {
  if (!tavilyApiKey) {
    return {
      videos: ["https://youtube.com"], 
      images: ["https://unsplash.com"]
    };
  }

  try {
    const response = await fetch('https://tavily.com', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: tavilyApiKey,
        query: `how to perform first aid for ${medicalIssue} instructional step by step tutorial diagram layout`,
        search_depth: "basic",
        include_images: true,
        max_results: 3
      })
    });

    const searchData = await response.json();
    
    const liveImages = searchData.images && searchData.images.length > 0 
      ? searchData.images 
      : ["https://unsplash.com"];

    const liveVideos = [];
    if (searchData.results) {
      for (const result of searchData.results) {
        if (result.url.includes('youtube.com') || result.url.includes('youtu.be') || result.url.includes('vimeo')) {
          liveVideos.push(result.url);
        }
      }
    }
    
    if (liveVideos.length === 0) {
      liveVideos.push(`https://youtube.com{encodeURIComponent(medicalIssue)}`);
    }

    return { videos: liveVideos.slice(0, 2), images: liveImages.slice(0, 2) };
  } catch (error) {
    console.error("Live Web Search Media Pipeline Failure:", error);
    return { videos: [], images: [] };
  }
}

// Primary root endpoint for system validation checks
app.get('/', (req, res) => {
  res.status(200).send("🚀 VoxMed Master Integrated Triage Server is fully aligned with Priti's database.");
});

// =========================================================================
// UNIFIED MASTER TRIAGE ROUTER (VOCAL, MULTIMEDIA, GEOSPATIAL, BIOMETRIC)
// =========================================================================
app.post('/api/triage', async (req, res) => {
  const startTime = Date.now(); // Instantly marks execution speed metrics for data reports
  
  try {
    const { 
      transcript, 
      admin_location, 
      latitude, 
      longitude, 
      victim_age_group,
      cpr_depth_inches, 
      cpr_speed_bpm,
      self_injury_alert,   
      live_heart_rate,      
      time_motionless_secs  
    } = req.body;

    const targetAge = victim_age_group || "Adult"; 
    let executionContextText = transcript || "";

    // 1. DYNAMIC SYSTEM-LEVEL HARD-FALL DETECTOR OVERRIDE
    if (self_injury_alert === true) {
      executionContextText = `AUTOMATED CRITICAL ALERT: Device user suffered a high-G impact fall. `;
      if (time_motionless_secs && time_motionless_secs > 10) {
        executionContextText += `User has been completely motionless for ${time_motionless_secs} seconds. Suspected unconsciousness. `;
      }
      if (live_heart_rate) {
        executionContextText += `Smartwatch sensor reads current heart rate at ${live_heart_rate} BPM.`;
      }
    }

    if (!executionContextText) {
      return res.status(400).json({ error: "No input variables provided." });
    }

    // 2. LIVE TELEMETRY PHYSICAL COMPLIANCE AUDIT
    let sensorQualityFeedback = "";
    if (cpr_depth_inches && cpr_depth_inches < 2.0) {
      sensorQualityFeedback = " CRITICAL LOG: Accelerometer detects compression depth is too shallow. Forcefully tell the user to PUSH HARDER.";
    }
    if (cpr_speed_bpm && (cpr_speed_bpm < 100 || cpr_speed_bpm > 120)) {
      sensorQualityFeedback += ` CRITICAL LOG: Gyroscope detects compression pace is out of clinical bounds at ${cpr_speed_bpm} BPM. Enforce strict 110 BPM rhythm tracking.`;
    }

    // ==========================================================
    // TIER 1: MULTI-MODAL RELATIONAL SCHEMA SEARCH (Priti's Columns)
    // ==========================================================
    const { data: localProtocols, error: dbError } = await supabase
      .from('medical_protocols')
      .select('incident_name, symptoms_keywords, steps_to_take, warning_notes, image_url, video_url');

    if (dbError) throw dbError;

    const systemPrompt = `
      You are an elite emergency medical AI dispatcher running an advanced Multi-Layer Triage runtime framework.
      Analyze the input context string against this database of local clinical protocols:
      ${JSON.stringify(localProtocols)}

      LIVE MONITORING HARDWARE telemetry updates:
      - Current Heart Rate Metric: ${live_heart_rate || 'Unknown'} BPM.
      - Hardware Sensor Quality Corrections: ${sensorQualityFeedback || 'All metrics optimal.'}

      CRITICAL OPERATION HANDBOOKS:
      1. Target Demographic Context: The victim is an ${targetAge}.
      2. Automated Self-Injury Handling: If input context states 'AUTOMATED CRITICAL ALERT', the user has been hurt themselves. Your response text should act as a loud audible broadcast beacon to alert surrounding individuals and command immediate hospital transfer.
      3. Tier 1 (DB Match): If keywords align with a local protocol, return that exact corresponding "steps_to_take". Set "status" to "Resolved Automatically".
      4. Tier 2 (Web Search Fallback): If the scenario matches 0 rows in your table parameters, provide a safe, generic first-aid stabilization baseline. Set "status" to "pending_review".

      You must return your output strictly as a single JSON object matching this structure:
      {
        "medical_issue": "Protocol Name OR 'Automated Crash Event'",
        "ai_response": "Short, clear, commanding guide incorporating live sensor adjustments (Max 3 sentences)",
        "status": "Resolved Automatically" OR "pending_review"
      }
    `;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: executionContextText }
      ],
      response_format: { type: 'json_object' }
    });

    let triageResult = JSON.parse(completion.choices.message.content || '{}');

    // Live internet media search execution
    const liveMedia = await searchLiveInternetMedia(triageResult.medical_issue);
    triageResult.videos = liveMedia.videos;
    triageResult.images = liveMedia.images;
    triageResult.navigation_url = null; 

    // ==========================================================
    // TIER 3: GEOSPATIAL PROXIMITY ROUTING via Priti's RPC
    // ==========================================================
    if (triageResult.status === 'pending_review' || self_injury_alert === true) {
      let routingInstructions = " Please immediately contact local emergency services directly.";
      
      if (latitude && longitude) {
        // Execute Priti's native SQL function directly inside the database engine
        const { data: closestHospitals, error: rpcError } = await supabase.rpc('get_nearby_hospitals', {
          user_lat: parseFloat(latitude),
          user_lng: parseFloat(longitude),
          limit_count: 1
        });

        if (!rpcError && closestHospitals && closestHospitals.length > 0) {
          const nearest = closestHospitals[0];
          routingInstructions = ` Nearest medical facility detected at ${parseFloat(nearest.distance_km).toFixed(1)} km. Proceed immediately to the emergency room at: ${nearest.name} (${nearest.specialty_tags?.join(', ') || 'Emergency Care'}).`;
          
          // Pulling Priti's auto-generated directions URL parameter directly
          triageResult.navigation_url = nearest.google_maps_directions_url || null;
        }
      }
      
      triageResult.ai_response += routingInstructions;
    }

    const executionLatency = Date.now() - startTime;

    // Write complete transaction telemetry straight into Priti's logs schema
    await supabase.from('emergency_logs').insert({
      admin_location: admin_location || 'Global Hub Core',
      user_input_transcript: executionContextText,
      ai_response: triageResult.ai_response,
      status: triageResult.status,
      latency_ms: executionLatency,
      timestamp: new Date().toISOString()
    });

    return res.status(200).json(triageResult);

  } catch (error) {
    console.error('Critical Core Server Exception Handling Triggered:', error);
    return res.status(500).json({ error: 'Core server processing time limit reached.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Master Integrated Triage Engine active on port ${PORT}`));