/*
# Create emergency triage tables

## Purpose
Supports a dynamic emergency triage backend that reads medical protocols,
runs OpenAI chat completions on caller transcripts, and logs every triage
result. When the AI cannot reach a confident result it falls back to routing
the caller to the nearest hospital.

## New Tables

### medical_protocols
Stores triage protocols keyed by condition. The AI reads these to ground its
assessment.
- `id` (uuid, primary key)
- `condition` (text, unique, not null) — e.g. "chest_pain", "stroke"
- `protocol_text` (text, not null) — full triage instructions for that condition
- `severity_level` (text, not null, default 'moderate') — "low", "moderate", "high", "critical"
- `created_at` (timestamptz, default now())

### hospitals
Stores hospital records used for fallback routing when the AI result is
"AI_Failed_Needs_Review".
- `id` (uuid, primary key)
- `name` (text, not null)
- `address` (text)
- `phone` (text)
- `latitude` (double precision)
- `longitude` (double precision)
- `emergency_capacity` (boolean, default true) — whether ER is accepting
- `created_at` (timestamptz, default now())

### emergency_logs
Append-only audit log of every triage request and its result, including
latency, AI output, and fallback routing decisions.
- `id` (uuid, primary key)
- `transcript` (text, not null) — the caller's transcript submitted for triage
- `triage_result` (jsonb) — the structured JSON returned by the AI
- `fallback_hospital_id` (uuid, references hospitals.id, nullable) — set only on AI fallback
- `processing_latency_ms` (integer, not null) — measured execution time in ms
- `created_at` (timestamptz, default now())

## Security
- All three tables enable Row Level Security.
- This is a single-tenant emergency backend (no user sign-in), so all policies
  use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)` so the
  anon-key server client can read and write.
- `emergency_logs` is INSERT-only from the API (logs are never updated or deleted),
  but we provide full CRUD policies for operational flexibility.

## Notes
1. All tables use `gen_random_uuid()` for primary keys.
2. The `emergency_logs.fallback_hospital_id` FK uses `ON DELETE SET NULL` so
   deleting a hospital never loses log history.
*/

CREATE TABLE IF NOT EXISTS medical_protocols (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  condition text UNIQUE NOT NULL,
  protocol_text text NOT NULL,
  severity_level text NOT NULL DEFAULT 'moderate',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE medical_protocols ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_medical_protocols" ON medical_protocols;
CREATE POLICY "anon_select_medical_protocols" ON medical_protocols FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_medical_protocols" ON medical_protocols;
CREATE POLICY "anon_insert_medical_protocols" ON medical_protocols FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_medical_protocols" ON medical_protocols;
CREATE POLICY "anon_update_medical_protocols" ON medical_protocols FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_medical_protocols" ON medical_protocols;
CREATE POLICY "anon_delete_medical_protocols" ON medical_protocols FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS hospitals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  address text,
  phone text,
  latitude double precision,
  longitude double precision,
  emergency_capacity boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hospitals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_hospitals" ON hospitals;
CREATE POLICY "anon_select_hospitals" ON hospitals FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_hospitals" ON hospitals;
CREATE POLICY "anon_insert_hospitals" ON hospitals FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_hospitals" ON hospitals;
CREATE POLICY "anon_update_hospitals" ON hospitals FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_hospitals" ON hospitals;
CREATE POLICY "anon_delete_hospitals" ON hospitals FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS emergency_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transcript text NOT NULL,
  triage_result jsonb,
  fallback_hospital_id uuid REFERENCES hospitals(id) ON DELETE SET NULL,
  processing_latency_ms integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE emergency_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_emergency_logs" ON emergency_logs;
CREATE POLICY "anon_select_emergency_logs" ON emergency_logs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_emergency_logs" ON emergency_logs;
CREATE POLICY "anon_insert_emergency_logs" ON emergency_logs FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_emergency_logs" ON emergency_logs;
CREATE POLICY "anon_update_emergency_logs" ON emergency_logs FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_emergency_logs" ON emergency_logs;
CREATE POLICY "anon_delete_emergency_logs" ON emergency_logs FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_medical_protocols_condition ON medical_protocols (condition);
CREATE INDEX IF NOT EXISTS idx_emergency_logs_created_at ON emergency_logs (created_at DESC);
