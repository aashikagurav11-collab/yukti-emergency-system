import { useState, useEffect } from 'react';

export default function FirstAidApp() {
  const [isListening, setIsListening] = useState(false);
  const [userInputTranscript, setUserInputTranscript] = useState('');
  const [victimAgeGroup, setVictimAgeGroup] = useState('Adult');
  const [adminLocation, setAdminLocation] = useState('Zone-A-Mumbai');
  
  const [inputMode, setInputMode] = useState('voice');
  const [typedText, setTypedText] = useState('');

  const [coords, setCoords] = useState(null);

  const [medicalIssue, setMedicalIssue] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [status, setStatus] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Background GPS Fetching
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setCoords({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
        (err) => console.log("GPS Location default used:", err)
      );
    }
  }, []);

  const startListening = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      alert("Microphone access blocked. Please allow permissions in your browser bar.");
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. Please use Chrome or Edge.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event) => {
        const textSpoken = event.results[0][0].transcript;
        setUserInputTranscript(textSpoken);
        setIsListening(false);
        sendToBackend(textSpoken);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch (error) {
      setIsListening(false);
    }
  };

  const speakOutLoud = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Real Backend API Call (Shows 'Backend is not connected' when endpoint fails)
  const sendToBackend = async (transcriptText) => {
    if (!transcriptText || !transcriptText.trim()) return;

    setIsLoading(true);

    // Replace this placeholder with your actual live backend endpoint after integration!
    const BACKEND_URL = 'https://your-bolt-backend-url.run/api/triage';

    try {
      const response = await fetch(BACKEND_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_input_transcript: transcriptText,
          admin_location: adminLocation,
          latitude: coords?.latitude,
          longitude: coords?.longitude,
          victim_age_group: victimAgeGroup
        })
      });

      if (!response.ok) throw new Error("Backend connection failed");

      const data = await response.json();
      setMedicalIssue(data.medical_issue || 'Emergency Processing');
      setAiResponse(data.ai_response || 'No response generated.');
      setStatus(data.status || 'Verified Protocol');

      if (data.ai_response) {
        speakOutLoud(data.ai_response);
      }

    } catch (error) {
      console.warn("Backend API request failed:", error);
      
      // Clean display when backend is not connected
      setMedicalIssue('System Status');
      setAiResponse('Backend is not connected.');
      setStatus('Offline');
      speakOutLoud('Backend is not connected.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTextSubmit = (e) => {
    e.preventDefault();
    if (!typedText.trim()) return;
    setUserInputTranscript(typedText);
    sendToBackend(typedText);
    setTypedText('');
  };

  return (
    <div className="min-h-screen bg-[#030914] text-white p-6 font-sans flex flex-col items-center justify-between">
      
      {/* Container */}
      <div className="w-full max-w-2xl flex flex-col items-center flex-grow">
        
        {/* Header */}
        <header className="w-full flex justify-between items-center mb-10 border-b border-blue-900/30 pb-5">
          <div className="flex items-center gap-3">
            <span className="w-3.5 h-3.5 rounded-full bg-red-600 animate-pulse shadow-[0_0_12px_rgba(220,38,38,0.9)]"></span>
            <div>
              <h1 className="text-xl font-black tracking-tight text-white uppercase">YUKTI</h1>
              <p className="text-[10px] text-slate-400 tracking-widest uppercase font-semibold">VOICE AI EMERGENCY ASSISTANT</p>
            </div>
          </div>

          <button className="text-xs font-semibold px-4 py-1.5 bg-red-950/40 text-red-400 border border-red-800/50 rounded-full">
            Emergency Mode
          </button>
        </header>

        <main className="w-full space-y-6 flex-grow">
          {/* Main Title */}
          <div className="text-center space-y-2 mb-8">
            <h2 className="text-3xl font-extrabold text-white tracking-tight">
              Instant First-Aid Voice Guidance
            </h2>
            <p className="text-sm text-slate-300 max-w-lg mx-auto">
              Speak naturally to receive real-time, step-by-step emergency medical protocols.
            </p>
          </div>

          {/* Age Category Dropdown */}
          <div className="flex justify-between items-center bg-[#071326] p-4 rounded-xl border border-blue-900/40">
            <label className="text-sm font-medium text-slate-200">Victim Age Category:</label>
            <select 
              value={victimAgeGroup} 
              onChange={(e) => setVictimAgeGroup(e.target.value)}
              className="bg-[#030914] border border-blue-800/60 text-white text-sm rounded-lg p-2 outline-none"
            >
              <option value="Adult">Adult</option>
              <option value="Child">Child</option>
              <option value="Infant">Infant</option>
            </select>
          </div>

          {/* Glowing Microphone Section */}
          {inputMode === 'voice' ? (
            <div className="flex flex-col items-center justify-center p-10 bg-[#071326]/60 rounded-2xl border border-blue-900/30 relative my-6">
              <button
                type="button"
                onClick={startListening}
                disabled={isLoading}
                className={`w-36 h-36 rounded-full flex flex-col items-center justify-center text-lg font-bold shadow-[0_0_40px_rgba(220,38,38,0.6)] transition-transform ${
                  isListening 
                    ? 'bg-red-600 animate-pulse scale-105' 
                    : 'bg-red-600 hover:scale-105'
                }`}
              >
                <svg className="w-10 h-10 mb-1 fill-current text-white" viewBox="0 0 24 24">
                  <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z" />
                  <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
                </svg>
                <span className="text-xs font-black tracking-wider uppercase text-white">
                  {isListening ? 'LISTENING...' : 'TAP TO SPEAK'}
                </span>
              </button>

              <p className="mt-6 text-xs text-slate-400 font-medium">
                {isListening ? 'Listening... Speak clearly into your microphone' : 'Tap the button and describe the emergency situation'}
              </p>

              {/* Mode Toggle Pills */}
              <div className="flex gap-2 mt-6">
                <button
                  type="button"
                  onClick={() => setInputMode('voice')}
                  className="text-xs font-semibold px-4 py-1.5 rounded-md bg-[#030914] text-white border border-blue-800/50"
                >
                  Voice On
                </button>
                <button
                  type="button"
                  onClick={() => setInputMode('text')}
                  className="text-xs font-semibold px-4 py-1.5 rounded-md bg-[#030914] text-slate-400 hover:text-white border border-blue-900/30"
                >
                  Type Instead
                </button>
              </div>
            </div>
          ) : (
            /* Text Input Mode */
            <form onSubmit={handleTextSubmit} className="flex flex-col gap-3 p-6 bg-[#071326] rounded-2xl border border-blue-900/40">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Type Emergency Description:
              </label>
              <textarea
                value={typedText}
                onChange={(e) => setTypedText(e.target.value)}
                placeholder="e.g., Severe cut on arm, bleeding continuously..."
                rows="3"
                className="w-full bg-[#030914] border border-blue-800/60 text-white text-sm rounded-xl p-3 outline-none"
              />
              <div className="flex gap-3">
                <button
                  type="submit"
                  disabled={isLoading || !typedText.trim()}
                  className="flex-grow py-2.5 bg-red-600 hover:bg-red-500 font-bold text-sm rounded-xl transition"
                >
                  Send Emergency Report
                </button>
                <button
                  type="button"
                  onClick={() => setInputMode('voice')}
                  className="px-4 py-2.5 bg-[#030914] text-slate-300 text-xs rounded-xl border border-blue-800/50"
                >
                  Back to Voice
                </button>
              </div>
            </form>
          )}

          {/* Transcript Box */}
          {userInputTranscript && (
            <div className="p-4 bg-[#071326] rounded-xl border border-blue-900/40">
              <span className="text-xs font-semibold text-slate-400 uppercase block mb-1">Spoken / Typed Input:</span>
              <p className="text-sm font-mono text-slate-200">"{userInputTranscript}"</p>
            </div>
          )}

          {/* Loading Bar */}
          {isLoading && (
            <div className="p-4 bg-blue-950/60 text-amber-300 rounded-xl border border-amber-500/30 text-center text-sm animate-pulse font-medium">
              Connecting to backend server...
            </div>
          )}

          {/* Response Box */}
          {aiResponse && (
            <div className="p-6 bg-[#071326] border border-blue-800/40 rounded-2xl space-y-3">
              <div className="flex justify-between items-center border-b border-blue-900/40 pb-2">
                <h3 className="text-lg font-bold text-red-400">{medicalIssue}</h3>
                <span className={`text-xs px-2.5 py-1 rounded font-semibold ${
                  status === 'Offline' 
                    ? 'bg-red-950/80 text-red-300 border border-red-700/50' 
                    : 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/50'
                }`}>
                  {status}
                </span>
              </div>
              <p className="text-base text-slate-100 leading-relaxed">{aiResponse}</p>

              <button 
                type="button"
                onClick={() => speakOutLoud(aiResponse)}
                className="mt-2 text-xs text-slate-400 hover:text-white underline flex items-center gap-1"
              >
                🔊 Replay Voice Audio
              </button>
            </div>
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="w-full max-w-2xl mt-8 pt-4 border-t border-blue-900/20 text-center">
        <p className="text-xs text-slate-400">
          This guidance is for immediate assistance while emergency services (e.g., 108) are on their way.{" "}
          <span className="text-white font-semibold">Always call professional help immediately.</span>
        </p>
      </footer>
    </div>
  );
}